"""Read-only scientific inputs, immutable startup snapshots and source-byte delta backup."""
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent.parent
OLD=Path('/workspace/guardfed_checks/celeba_hybrid_cuda_execution_20261009/execution_attachments/startup_backup/hybrid_cuda_source_startup_20261009.tar.gz')
OLD_SHA='1876769e6073b00ef1131d57a855611d60ab6863f144fefb3bbd20e7ac07d791'
SOURCE_SHA='2c496ae11369465d27ed223f8552321ec8cd424e5fd87e9f2d34e5ea8531e06f'
APPROVED_SHA='c984c7bf910ce87156c4901f559eac30f7aebbad28858a942dd5343226c476ee'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def main():
    assert HERE==Path('/workspace/guardfed_checks/celeba_hybrid_screen_execution_20261009')
    assert sha(HERE/'FILES_SHA256.json')==SOURCE_SHA and sha(HERE/'APPROVED_screen.json')==APPROVED_SHA
    assert sha(OLD)==OLD_SHA
    with tarfile.open(OLD,'r:gz') as tar:old_inventory=json.loads(tar.extractfile('backup_inventory.json').read())
    lookup={}
    for name,item in sorted(old_inventory['members'].items()):lookup.setdefault((item['sha256'],item['bytes']),name)
    sys.path.insert(0,str(HERE));import body
    scope=read(HERE/'screen_scope.json');body.verify_scope(scope)
    for name,expected in read(HERE/'FILES_SHA256.json')['files'].items():assert sha(HERE/name)==expected
    assert read(HERE/'runtime_protocol.json')['status']=='FROZEN' and not (HERE/'gate_runs').exists()
    assert not (HERE/'screen_failure.json').exists() and not (HERE/'screen_complete.json').exists()
    entry=scope['jobs'][0];out=HERE/entry['output'];assert not (out/'failure.json').exists()
    progress=read(out/'progress.json');diagnostics=read(out/'diagnostics.json');prov=read(out/'provenance.json')
    assert progress['round']>=1 and len(diagnostics)>=1 and sum(diagnostics[0]['client_counts'])==146493
    assert prov['cpu_affinity']==[104] and prov['cpu_threads']==1 and prov['device']=='cuda:0' and prov['cuda_device_count']==1 and prov['cuda_visible_devices']=='0' and prov['gpu_uuid']=='GPU-da357477-30a7-fddc-344b-a20513b9a2d0'
    assert prov['torch']=='2.11.0+cu128' and prov['cuda_build']=='12.8' and prov['source_hashes']==scope['protected_source_hashes'] and prov['local_hashes']==scope['local_hashes']
    workers=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:
            argv=[x.decode(errors='replace') for x in (proc/'cmdline').read_bytes().split(b'\0') if x]
            if str(HERE/'driver.py') in argv:
                assert argv[-1]==APPROVED_SHA and argv[argv.index('--kind')+1]=='screen'
                pid=int(proc.name);assert sorted(os.sched_getaffinity(pid))==[104] and os.getpriority(os.PRIO_PROCESS,pid)==10
                workers.append(dict(pid=pid,argv=argv,cwd=str((proc/'cwd').resolve()),cpus=[104],nice=10))
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
    assert len(workers)==1 and prov['pid']==workers[0]['pid']
    service=subprocess.run(['supervisorctl','status','guardfed_celeba_hybrid_screen32'],capture_output=True,text=True).stdout.strip();assert 'RUNNING' in service
    before=read(HERE/'screen_dispatch.json')['resources_before'];after=body.snapshot();prior={r['id']:r['round'] for r in before['active']}
    growth=[dict(id=r['id'],before=prior[r['id']],after=r['round']) for r in after['active'] if r['id'] in prior and r['round'] is not None and prior[r['id']] is not None and r['round']>prior[r['id']]]
    assert not after['failed'] and (growth or after['completed']>before['completed'])
    b=HERE/'execution_dispatch_v1/startup_incremental_backup';b.mkdir()
    save(b/'first_progress_snapshot.json',progress);save(b/'first_diagnostics_snapshot.json',diagnostics)
    (b/'service_log_prefix.txt').write_bytes(Path('/var/log/guardfed_celeba_hybrid_screen32.log').read_bytes())
    save(b/'live_launch_receipt.json',dict(status='SCREEN32_STARTED_FIRST_REAL_ROUND_VERIFIED_NOT_70ROUND_ACCEPTANCE',at_unix=time.time(),service=service,workers=workers,first_job=entry,first_progress_round=progress['round'],first_client_rows=146493,provenance=prov,source69_before_after_verified=True,protected28_source_data_before_after_verified=True,protected_formal_before=before,protected_formal_after=after,protected_formal_real_growth=growth,protected_formal_completed_growth=after['completed']-before['completed'],scientific_accepted_records=0,formal100_started=False,test_started=False,automatic_retry=False))
    reused={};fresh={};source_members=read(HERE/'FILES_SHA256.json')['files']
    for name,expected in source_members.items():
        path=HERE/name;key=expected,path.stat().st_size
        if key in lookup:reused[name]=dict(source_archive_sha256=OLD_SHA,source_member=lookup[key],sha256=expected,bytes=key[1])
        else:fresh[name]=path
    extras=[HERE/'FILES_SHA256.json',HERE/'APPROVED_screen.json',HERE/'APPROVED_screen.sha256',HERE/'screen_dispatch.json',out/'provenance.json',out/'resource_before.json']
    extras += [p for sub in ['execution_attachments','execution_dispatch_v1'] for p in sorted((HERE/sub).iterdir()) if p.is_file() and p.suffix!='.gz']
    extras += list(b.iterdir())
    for path in extras:
        name=str(path.relative_to(HERE));assert name not in fresh and name not in reused;fresh[name]=path
    restore=dict(status='SOURCE69_EXACT_RESTORE_MAP_WITH_VERIFIED_OLD_BYTES_REUSED',source_seal_sha256=SOURCE_SHA,expected_source_members=source_members,reused_members=reused,fresh_source_members=[name for name in source_members if name not in reused],prior_archive_sha256=OLD_SHA,prior_archive_inventory_sha256=sha(OLD.parent/'backup_inventory.json'))
    save(b/'SOURCE_RESTORE_MAP.json',restore);fresh[str((b/'SOURCE_RESTORE_MAP.json').relative_to(HERE))]=b/'SOURCE_RESTORE_MAP.json'
    inventory=dict(status='SCREEN32_SOURCE_STARTUP_INCREMENTAL_ONLY_NOT_SCIENTIFIC_ACCEPTANCE',accepted_new_ids=[],source_host=socket.gethostname(),source_seal_sha256=SOURCE_SHA,scope_sha256=sha(HERE/'screen_scope.json'),runtime_protocol_sha256=sha(HERE/'runtime_protocol.json'),approval_sha256=APPROVED_SHA,prior_source_archive_sha256=OLD_SHA,reused_members=reused,members={name:dict(sha256=sha(path),bytes=path.stat().st_size) for name,path in sorted(fresh.items())})
    save(b/'backup_inventory.json',inventory)
    archive=b/'hybrid_screen32_source_startup_incremental_20261009.tar.gz'
    with tarfile.open(archive,'x:gz') as tar:
        tar.add(b/'backup_inventory.json',arcname='backup_inventory.json',recursive=False)
        for name,path in sorted(fresh.items()):tar.add(path,arcname=name,recursive=False)
    receipt=dict(status='SOURCE_STARTUP_INCREMENTAL_ARCHIVED_PENDING_OFFSERVER',accepted_new_ids=[],source_host=socket.gethostname(),archive_sha256=sha(archive),inventory_sha256=sha(b/'backup_inventory.json'),source_seal_sha256=SOURCE_SHA,scope_sha256=sha(HERE/'screen_scope.json'),prior_source_archive_sha256=OLD_SHA,fresh_members=len(fresh),reused_source_members=len(reused),expected_source_members=69,backup_collector_sha256=sha(__file__),scientific_accepted_records=0)
    save(b/'backup_receipt.json',receipt)
    print(json.dumps(receipt))


if __name__=='__main__':main()
