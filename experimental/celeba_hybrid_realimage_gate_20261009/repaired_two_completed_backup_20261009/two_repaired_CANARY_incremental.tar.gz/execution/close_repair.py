"""Strict closure and incremental backup only after the two repaired canaries pass."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
REPAIR = STAGE / 'execution_repair_v1'
RUNTIME = REPAIR / 'runtime_overlay'
DESTINATION = HERE / 'accepted_two_incremental_backup'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):
            h.update(block)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
    assert not path.exists()
    path.write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())

summary=read(RUNTIME/'repair_summary.json')
assert summary['status']=='PASS_TWO_NEW_CANARIES_TWO_REUSED_IID_CANARIES' and summary['new_actual_runs']==2
assert not (RUNTIME/'repair_failure.json').exists() and not DESTINATION.exists()
status=subprocess.run(['supervisorctl','status','guardfed_celeba_hybrid_writer_repair_v2'],capture_output=True,text=True).stdout.strip()
assert 'EXITED' in status
os.sched_setaffinity(0,list(range(8,16)))
os.environ.update(CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='8',MKL_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',NUMEXPR_NUM_THREADS='8')
sys.path.insert(0,str(REPAIR))
import repair_execute
gate,scope,original=repair_execute.inspect()
gate.verify_scope(original)
import torch
torch.set_num_threads(8);torch.set_num_interop_threads(1)
runner,checker,compare=repair_execute.functions(gate,scope,original)
reused=gate.compare(dict(original,jobs=original['jobs'][:2]))
new=[]
for entry in scope['new_jobs']:
    result=checker(entry,original);assert result is not None
    out=RUNTIME/entry['output']
    new.append(dict(id=entry['id'],metrics=result['metrics'],job_sha256=entry['job_sha256'],
        checkpoint_sha256=digest(out/'model.pt'),acceptance_sha256=digest(out/'acceptance.json'),
        undefined_sidecar_sha256=digest(out/'undefined_diagnostics.json'),
        explicit_undefined_diagnostics=read(out/'undefined_diagnostics.json')['undefined_values']))
new_pairs=compare(dict(original,jobs=scope['new_jobs']))
DESTINATION.mkdir()
delivery=dict(status='TWO_NEW_CANARIES_STRICT_ACCEPTED_TWO_OLD_IID_REFERENCED_BACKUP_PENDING',
    new_CANARY=2,reused_CANARY=2,new_actual_rounds=6,scientific_table_records=0,records=new,
    new_pairs=new_pairs,reused_pairs=reused,original_failed_stage_status='TERMINAL_FAILURE_UNCHANGED',
    old_failure_archive_sha256=scope['original_failed_attempt_archive_sha256'],
    original_failure_not_reclassified=True,formal_screen_status='PREPARED_NOT_FROZEN',test_evaluated=False,
    repeated_IID_inference_or_training=0,no_model_or_image_inference_performed_by_closure=True,
    metadata_boundary='Original training loader may materialize test-tail attributes; no test image inference/fitting/selection',
    source9_seal_sha256=digest(REPAIR/'FILES_SHA256.json'),scope_sha256=digest(REPAIR/'REPAIR_SCOPE.json'),
    protected_source_data_hashes=original['protected_source_hashes'],formal_after=gate.snapshot(),
    closure_script_sha256=digest(__file__))
save(DESTINATION/'strict_delivery.json',delivery)
files={}
def add(path,name):
    path=Path(path);assert path.is_file() and not path.is_symlink() and name not in files
    files[name]=dict(path=path,sha256=digest(path),bytes=path.stat().st_size)
for entry in scope['new_jobs']:
    for path in sorted((RUNTIME/entry['output']).iterdir()):
        add(path,'new/'+entry['id']+'/'+path.name)
for name in read(REPAIR/'FILES_SHA256.json')['files']:
    add(REPAIR/name,'repair_source/'+name)
add(REPAIR/'FILES_SHA256.json','repair_source/FILES_SHA256.json')
for name in ('dispatch_receipt.json','protected_before.json','protected_after.json','repair_summary.json'):
    add(RUNTIME/name,'runtime/'+name)
for name in ('APPROVED.json','APPROVED.sha256','preflight.json','installation_receipt.json','capture_launch_failure.py',
             'launcher_failure_v1/failure.json','launcher_failure_v1/FILES_SHA256.json',
             'launcher_failure_v1/guardfed_celeba_hybrid_writer_repair.sh','launcher_failure_v1/guardfed_celeba_hybrid_writer_repair.conf',
             'launcher_v2/service.sh','launcher_v2/supervisor.conf','launcher_v2/install_once.py',
             'launcher_v2/RECOVERY_AUTHORIZED.json','launcher_v2/start_receipt.json','launcher_v2/run.log',
             'launcher_v2/helper_pre_dispatch_failure.json','launcher_v2/install_once_failed_helper_v1.py','close_repair.py'):
    add(HERE/name,'execution/'+name)
add(DESTINATION/'strict_delivery.json','strict_delivery.json')
inventory=dict(accepted_new_ids=[r['id'] for r in new],record_kind='CANARY_NOT_SCIENTIFIC_TABLE',scientific_table_records=0,
    previous_evidence_archive_sha256=scope['original_failed_attempt_archive_sha256'],
    reused_IID_acceptance_references=read(REPAIR/'reused_IID_references.json'),
    members={name:{k:row[k] for k in ('sha256','bytes')} for name,row in files.items()})
payload=(json.dumps(inventory,indent=2,allow_nan=False)+'\n').encode()
archive=DESTINATION/'two_repaired_CANARY_incremental.tar.gz'
with tarfile.open(archive,'w:gz') as handle:
    info=tarfile.TarInfo('backup_inventory.json');info.size=len(payload);handle.addfile(info,io.BytesIO(payload))
    for name,row in sorted(files.items()):
        assert digest(row['path'])==row['sha256'] and row['path'].stat().st_size==row['bytes']
        handle.add(row['path'],arcname=name,recursive=False)
save(DESTINATION/'backup_receipt.json',dict(archive_sha256=digest(archive),inventory_sha256=hashlib.sha256(payload).hexdigest(),
    accepted_new_ids=inventory['accepted_new_ids'],members=len(files)+1,source_host=socket.gethostname(),
    previous_evidence_archive_sha256=scope['original_failed_attempt_archive_sha256'],scientific_table_records=0,
    reused_IID_models_repacked=0,original_scientific_result_models_repacked=0))
print(json.dumps(dict(status=delivery['status'],archive=str(archive),archive_sha256=digest(archive),members=len(files)+1)),flush=True)
