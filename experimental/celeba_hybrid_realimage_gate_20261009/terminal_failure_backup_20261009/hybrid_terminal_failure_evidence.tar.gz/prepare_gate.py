"""Freeze only the explicitly authorized 3-round CPU canaries; never change formal drafts."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import time

from gate import HERE, REPO, SEALED, digest, read, write


def local(project):
    source = project / 'tmp/celeba_baselines/remaining_20261009/group_a'
    assert not SEALED.exists(), 'Do not replace sealed snapshot'
    SEALED.mkdir()
    for name in ('worker.py', 'adapters.py', 'protocol.json', 'accept_result.py', 'prepare_jobs.py', 'FILES_SHA256.json'):
        shutil.copyfile(source / name, SEALED / name)
    shutil.copyfile(source / 'screen_jobs_draft/CosineFairness_lam20.0_tau0.2_lr0.001_IID_Benign_seed91001_screen.json',
                    HERE / 'sealed_formal_job.json')
    write(HERE / 'sealed_copy_receipt.json', dict(original_group_a_inventory_sha256=digest(source / 'FILES_SHA256.json'),
        original_directory=str(source), copied_hashes={p.name:digest(p) for p in SEALED.iterdir()},
        original_protocol_status=read(SEALED / 'protocol.json')['status'], formal_protocol_modified=False,
        formal_job_sha256=digest(HERE / 'sealed_formal_job.json')))


def freeze():
    assert sys.platform == 'linux' and str(HERE) == '/workspace/guardfed_checks/celeba_hybrid_realimage_gate_20261009'
    assert not (HERE / 'scope.json').exists(), 'Preserve frozen scope'
    protocol = read(SEALED / 'protocol.json')
    assert protocol['status'] == 'PREPARED_NOT_FROZEN'
    missing = [{'path':rel, 'expected_sha256':sha} for rel,sha in protocol['source_hashes'].items() if not (REPO / rel).is_file()]
    if missing:
        write(HERE / 'missing_source_inputs.json', missing)
        raise RuntimeError('Missing frozen inputs: ' + json.dumps(missing))
    for rel, expected in protocol['source_hashes'].items():
        assert digest(REPO / rel) == expected, ('Frozen historical source/data drift', rel)
    formal = REPO / 'results/revision_20261009/celeba_mechanism_v1'
    mf = read(formal / 'manifest.json')
    protected = dict(protocol['source_hashes'])
    for path, expected in mf['adapter_hashes'].items():
        assert digest(path) == expected, ('Formal adapter drift', path)
        protected[str(Path(path).relative_to(REPO))] = expected
    for name in ('manifest.json', 'PROTOCOL.md', 'dispatch_receipt.json'):
        protected[str((formal / name).relative_to(REPO))] = digest(formal / name)
    local_hashes = {str(p.relative_to(HERE)):digest(p) for p in SEALED.iterdir()}
    for name in ('gate.py', 'prepare_gate.py', 'sealed_formal_job.json', 'sealed_copy_receipt.json'):
        local_hashes[name] = digest(HERE / name)
    candidate = next(c for c in protocol['candidates'] if c['id'] == 'CosineFairness_lam20.0_tau0.2_lr0.001')
    jobs = []
    for distribution, attack in (('IID', 'Benign'), ('non-IID', 'S-DFA')):
        for method, suffix in (('CosineFairnessHybrid', 'hybrid'), ('GuardFed', 'legacy_reference')):
            identity = f'{distribution}_{attack}_{suffix}_seed91001_cpu_gate3'
            config = dict(protocol['base_config'], rounds=3, device='cpu', seed=91001,
                client_alpha=protocol['distributions'][distribution], learning_rate=candidate['learning_rate'],
                guardfed_fairness_lambda=candidate['adapter']['fairness_lambda'], trust_threshold=candidate['adapter']['threshold'],
                experiment_suite='celeba_hybrid_realimage_cpu_gate_20261009', experiment_tag=f'{distribution}_{attack}_paired_gate3')
            job = dict(id=identity, dataset='celeba', distribution=distribution, attack=attack, method=method,
                config=config, adapter=candidate['adapter'], evidence_stage='real_image_cpu_pipeline_gate_only',
                scientific_table_records=0, source_hashes=protocol['source_hashes'])
            file = HERE / 'jobs' / (identity + '.json'); write(file, job)
            jobs.append(dict(id=identity, job=str(file.relative_to(HERE)), job_sha256=digest(file), output='runs/' + identity))
    (HERE / 'runs').mkdir(exist_ok=False)
    guide_sha = digest('/etc/vast-agents-guide.md')
    assert guide_sha == '42be4f7a84349c7bca6f6b35c10e94d70ddeb9239bcdeaf0c56317d4ab3fd2aa'
    scope = dict(status='FROZEN_BOUNDED_CPU_IMAGE_GATE_ONLY', frozen_unix=time.time(),
        authorization='Parent delegated user-authorized missing experiments: two full-image three-round CPU gates plus same-horizon legacy references, 2026-10-09',
        formal_screen_status=protocol['status'], formal_protocol_sha256=digest(SEALED / 'protocol.json'),
        max_concurrent_cpu_processes=1, cpu_threads=8, expected_torch='2.11.0+cu128', expected_cuda_build='12.8',
        cpu_affinity_rule='sorted(os.sched_getaffinity(0))[8:16] at process launch; only this process and its threads',
        test_evaluation_authorized=False, scientific_table_records=0, jobs=jobs,
        protected_source_hashes=protected, local_hashes=local_hashes, guide_sha256=guide_sha,
        definition='ReLU cosine times exp(-lambda * attacked-local-model root AEOD); strict threshold; best fallback; equal selected mean; native argmax',
        limits='No formal32 screen authorization, GPU use, package/service/driver changes, or seventy-round equivalence claim')
    write(HERE / 'scope.json', scope)
    print(json.dumps(dict(status=scope['status'], jobs=len(jobs), protected_hashes=len(protected))), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('action', choices=['local', 'freeze'])
    parser.add_argument('--project', type=Path)
    args = parser.parse_args()
    local(args.project.resolve()) if args.action == 'local' else freeze()
