"""Read-only strict acceptance and one immutable backup of four finished canaries."""
import io
import json
import os
from pathlib import Path
import socket
import sys
import tarfile
import time

import shared_cache_wrapper

gate = shared_cache_wrapper.gate
shared_cache_wrapper.bind_shared_paths()
scope = gate.read(gate.HERE / 'scope.json')
receipt = gate.read(gate.HERE / 'dispatch_receipt.APPROVED.json')
destination = gate.HERE / 'completed_four_backup_20261009'
gate.require(not destination.exists(), 'Never overwrite closure or backup evidence')
gate.require(not (gate.HERE / 'gate_failure.json').exists(), 'Terminal failure blocks successful closure')
sys.argv = [str(gate.HERE / 'gate.py'), 'summarize', '--dispatch-receipt', str(gate.HERE / 'dispatch_receipt.APPROVED.json')]
gate.main()  # Original sealed acceptance; no run action, training or CNN inference.
summary = gate.read(gate.HERE / 'gate_summary.json')
gate.require(summary['status'] == 'PASS' and summary['real_image_runs'] == 4 and summary['actual_rounds'] == 12,
             'Missing completed gate summary')
gate.require(summary['scientific_table_records'] == 0 and summary['formal_decisions_unresolved'] == 5,
             'Canaries cannot freeze the scientific protocol')
records = []
for entry in scope['jobs']:
    out = gate.HERE / entry['output']
    result = gate.read(out / 'result.json')
    acceptance = gate.read(out / 'acceptance.json')
    audit = gate.read(out / 'gradient_audit.json')
    records.append(dict(id=entry['id'], job_sha256=entry['job_sha256'], method=result['method'],
        distribution=result['distribution'], attack=result['attack'], metrics=result['metrics'],
        checkpoint_sha256=gate.digest(out / 'model.pt'), checkpoint_tensor_sha256=acceptance['checkpoint_tensor_sha256'],
        acceptance_sha256=gate.digest(out / 'acceptance.json'), gradient_audit_sha256=gate.digest(out / 'gradient_audit.json'),
        real_same_point_client_gradients=len(audit), attack_sign_oracle_exact=all(row['attack_sign_oracle_exact'] for row in audit),
        local_optimizer_steps=sum(row['local_optimizer_steps'] for row in audit),
        elapsed_seconds=acceptance['elapsed_seconds']))
destination.mkdir()
delivery = dict(status='FOUR_EXPLORATORY_REAL_IMAGE_CANARIES_STRICT_PASS', checked_by_original_gate=True,
    real_image_runs=4, actual_rounds=12, scientific_table_records=0, formal_protocol_status='PREPARED_NOT_FROZEN',
    formal_decisions_unresolved=5, test_evaluated=False, no_test_image_inference=True,
    metadata_boundary='Original loader may materialize complete Smiling/Male and split metadata including test tail; no test images/inference/fitting/selection',
    records=records, original_scope_sha256=gate.digest(gate.HERE / 'scope.json'),
    protected_source_data_after=gate.hashes(gate.REPO, scope['protected_source_hashes']),
    current_resource=gate.snapshot(), complete_unix=time.time(), source_script_sha256=gate.digest(__file__))
gate.write(destination / 'strict_delivery.json', delivery)
files = {}
def add(path):
    path = Path(path)
    gate.require(path.is_file() and not path.is_symlink(), 'Nonregular backup input')
    name = path.relative_to(gate.HERE).as_posix()
    gate.require(name not in files, 'Duplicate backup member')
    files[name] = dict(path=path, sha256=gate.digest(path), bytes=path.stat().st_size)
for name in scope['local_hashes']:
    add(gate.HERE / name)
for name in receipt['execution_attachment_sha256']:
    if name not in files:
        add(gate.HERE / name)
for entry in scope['jobs']:
    if entry['job'] not in files:
        add(gate.HERE / entry['job'])
    for path in sorted((gate.HERE / entry['output']).iterdir()):
        add(path)
for name in ('scope.json', 'dispatch_receipt.APPROVED.json', 'SETUP_SHA256.json', 'EXECUTION_SHA256.json',
             'gate_summary.json', 'protected_before.json', 'protected_after.json', 'run.log',
             'prelaunch_identity_failure.json', 'close_realimage_gates_20261009.py'):
    path = gate.HERE / name
    if path.exists() and name not in files:
        add(path)
add(destination / 'strict_delivery.json')
ids = [entry['id'] for entry in scope['jobs']]
inventory = dict(schema='four_exploratory_gradient_canary_backup_v1', accepted_new_ids=ids,
    record_kind='CANARY_NOT_SCIENTIFIC_TABLE', scientific_table_records=0,
    members={name: {key: row[key] for key in ('sha256', 'bytes')} for name, row in files.items()})
data = (json.dumps(inventory, indent=2, allow_nan=False) + '\n').encode()
archive = destination / 'four_realimage_gradient_canaries.tar.gz'
with tarfile.open(archive, 'w:gz') as handle:
    info = tarfile.TarInfo('backup_inventory.json'); info.size = len(data)
    handle.addfile(info, io.BytesIO(data))
    for name, row in sorted(files.items()):
        gate.require(gate.digest(row['path']) == row['sha256'] and row['path'].stat().st_size == row['bytes'], 'Changed backup input')
        handle.add(row['path'], arcname=name, recursive=False)
gate.write(destination / 'backup_receipt.json', dict(archive_sha256=gate.digest(archive),
    inventory_sha256=__import__('hashlib').sha256(data).hexdigest(), accepted_new_ids=ids,
    members=len(files) + 1, source_host=socket.gethostname(), record_kind='CANARY_NOT_SCIENTIFIC_TABLE',
    scientific_table_records=0, test_evaluated=False, source_script_sha256=gate.digest(__file__)))
print(json.dumps(dict(status=delivery['status'], records=records, backup=str(archive), members=len(files) + 1)), flush=True)
