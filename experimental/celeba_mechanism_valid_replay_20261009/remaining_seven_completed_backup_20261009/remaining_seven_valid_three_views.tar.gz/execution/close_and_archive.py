"""Strict original-bridge recheck and seven-only incremental backup after normal exit."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tarfile

HERE=Path(__file__).resolve().parent
STAGE=HERE.parent/'remaining_seven_prepared_20261009'
DEST=HERE/'completed_seven_backup'
APPROVED_SHA='270721872c1a8a021d72f114c3300addcaceab4aa9435c4307e5471994101a05'
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(4*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
    with Path(path).open('x',encoding='utf-8') as out:out.write(json.dumps(value,indent=2,allow_nan=False)+'\n')

assert not DEST.exists() and not (STAGE/'batch_failure.json').exists()
assert os.getpriority(os.PRIO_PROCESS,0)>=10
os.sched_setaffinity(0,list(range(112,120)))
os.environ.update(CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='8',MKL_NUM_THREADS='8',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(STAGE))
import batch
scope,parent=batch.approved(STAGE/'APPROVED.json',APPROVED_SHA)
complete=read(STAGE/'batch_complete.json')
assert complete['status']=='SEVEN_VALID_REPLAYS_STRICT_ACCEPTED_BACKUP_PENDING'
assert [r['id'] for r in complete['records']]==batch.SELECTED
status=subprocess.run(['supervisorctl','status','guardfed_celeba_mechanism_valid_remaining7'],capture_output=True,text=True).stdout.strip()
assert 'EXITED' in status
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        argv=[s.decode(errors='replace') for s in (proc/'cmdline').read_bytes().split(b'\0') if s]
        assert str(STAGE/'batch.py') not in argv,'Remaining-seven compute process is still active'
    except (FileNotFoundError,ProcessLookupError,PermissionError):pass
strict=[]
for identity in batch.SELECTED:
    result=subprocess.run([sys.executable,'-u',str(STAGE/'batch.py'),'strict','--approved',str(STAGE/'APPROVED.json'),
        '--approved-sha256',APPROVED_SHA,'--id',identity],capture_output=True,text=True,check=True,timeout=120)
    strict.append(dict(id=identity,stdout=result.stdout,strict_acceptance_sha256=digest(Path(parent['outputs'][identity])/'strict_acceptance.json')))
DEST.mkdir()
delivery=dict(status='SEVEN_VALID_REPLAYS_ORIGINAL_BRIDGE_STRICT_ACCEPTED_BACKUP_PENDING',
    utc=datetime.now(timezone.utc).isoformat(),records=complete['records'],strict_rechecks=strict,
    native_tolerance=1e-12,max_abs_native_difference=max(r['native_difference'] for r in complete['records']),
    service=status,source12_seal_sha256=digest(STAGE/'FILES_SHA256.json'),APPROVED_sha256=APPROVED_SHA,
    new_training=0,new_Full_inference=0,new_test_inference=0,excluded_already_accepted='minus_U_IID_Benign_seed91002',
    paired_Full_three_views=read(STAGE/'Full_existing_references.json'),paired_missing_does_not_invalidate_mechanism_replay=True,
    original_single14_archive_not_repacked=True,original_models_not_repacked=True,
    final_protocol_status='PREPARED_NOT_FROZEN',closure_sha256=digest(__file__))
save(DEST/'strict_delivery.json',delivery)
files={}
def add(path,name):
    path=Path(path);assert path.is_file() and not path.is_symlink() and name not in files
    files[name]=dict(path=path,sha256=digest(path),bytes=path.stat().st_size)
for identity in batch.SELECTED:
    output=Path(parent['outputs'][identity])
    assert {p.name for p in output.iterdir()}=={'receipt.json','bridge_receipt.json','validation_predictions.npz','strict_acceptance.json'}
    for path in sorted(output.iterdir()):add(path,'runs/'+identity+'/'+path.name)
    for folder in ('approvals','logs'):
        add(STAGE/folder/(identity+('.json' if folder=='approvals' else '.log')),folder+'/'+identity+('.json' if folder=='approvals' else '.log'))
    add(STAGE/('completed_'+identity+'.json'),'runtime/completed_'+identity+'.json')
for name in [*read(STAGE/'FILES_SHA256.json')['files'],'FILES_SHA256.json']:
    add(STAGE/name,'sealed_source/'+name)
for name in ('APPROVED.json','APPROVED.sha256','batch_resource_before.json','batch_complete.json'):
    add(STAGE/name,'runtime/'+name)
for name in ('APPROVED.json','install_once.py','preflight.json','start_receipt.json','close_and_archive.py','verify_saved_seven.py'):
    add(HERE/name,'execution/'+name)
add(DEST/'strict_delivery.json','strict_delivery.json')
inventory=dict(accepted_new_ids=batch.SELECTED,original_inventory_sha256=batch.INVENTORY_SHA,
    source_seal_sha256=digest(STAGE/'FILES_SHA256.json'),new_training=0,new_Full_inference=0,
    excluded_already_accepted='minus_U_IID_Benign_seed91002',
    members={name:{k:row[k] for k in ('sha256','bytes')} for name,row in files.items()})
payload=(json.dumps(inventory,indent=2,allow_nan=False)+'\n').encode()
archive=DEST/'remaining_seven_valid_three_views.tar.gz'
with tarfile.open(archive,'w:gz') as out:
    info=tarfile.TarInfo('backup_inventory.json');info.size=len(payload);out.addfile(info,io.BytesIO(payload))
    for name,row in sorted(files.items()):
        assert digest(row['path'])==row['sha256'] and row['path'].stat().st_size==row['bytes']
        out.add(row['path'],arcname=name,recursive=False)
receipt=dict(archive_sha256=digest(archive),inventory_sha256=hashlib.sha256(payload).hexdigest(),
    accepted_new_ids=batch.SELECTED,members=len(files)+1,source_host=socket.gethostname(),new_training=0,new_Full_inference=0,
    original_checkpoint_models_repacked=0,original_single14_archive_repacked=0)
save(DEST/'backup_receipt.json',receipt)
print(json.dumps(dict(status=delivery['status'],archive=str(archive),archive_sha256=receipt['archive_sha256'],members=receipt['members'])),flush=True)
