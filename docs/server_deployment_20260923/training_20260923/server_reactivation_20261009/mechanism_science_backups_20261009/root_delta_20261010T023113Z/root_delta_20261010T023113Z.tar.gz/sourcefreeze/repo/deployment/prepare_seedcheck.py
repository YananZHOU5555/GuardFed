"""Freeze 42 new paired-seed jobs from the seven accepted score winners."""
import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/GuardFed-celeba-expanded')
OUT = ROOT / 'results/revision_20260925/celeba_seedcheck_v1'
PROTOCOL = ROOT / 'deployment/CELEBA_SEEDCHECK_PROTOCOL.md'
RANKING = ROOT / 'deployment/expanded_final/ranking.json'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

if __name__ == '__main__':
    assert not OUT.exists(), 'Refuse to overwrite frozen stage'
    ranked = json.loads(RANKING.read_text())
    winners = ranked['score_winners']
    assert len(winners) == 7 and len({r['method'] for r in winners}) == 7
    sources = {}
    for winner in winners:
        for row in winner['conditions']:
            result = json.loads((Path(row['output']) / 'result.json').read_text())
            job = result['revision_job']
            assert result['config'] == job['config']
            assert digest(Path(row['output']) / 'model.pt') == row['checkpoint_sha256']
            assert job['config']['seed'] == 91001 and job['config']['rounds'] == 70
            assert job['config']['celeba_evaluation_split'] == 'valid'
            assert job['tuning_candidate'] == winner['candidate']
            sources[(winner['method'], row['attack'])] = job
    assert len(sources) == 14
    OUT.mkdir(parents=True)
    (OUT / 'jobs').mkdir()
    selection = dict(ranking_sha256=digest(RANKING), source_jobs=list(sources.values()),
                     methods=[dict(method=w['method'], candidate=w['candidate']) for w in winners])
    write(OUT / 'selected_recipes.json', selection)
    base = json.loads((ROOT / 'results/revision_20260924/celeba_expanded_screen_v2/manifest.json').read_text())
    hashes = dict(base['source_hashes'])
    for name, expected in hashes.items():
        assert digest(ROOT / name) == expected, name
    for path in [Path(__file__).resolve(), PROTOCOL, OUT / 'selected_recipes.json', ROOT / 'deployment/run_celeba_migration.py']:
        hashes[str(path.relative_to(ROOT))] = digest(path)
    paths = []
    for seed in [91002, 91003, 91004]:
        for attack in ['Benign', 'S-DFA']:
            for winner in winners:
                original = sources[(winner['method'], attack)]
                job = {k: copy.deepcopy(v) for k, v in original.items() if k not in ['visible_gpu', 'cpu_threads', 'torch_version', 'python_version', 'checkpoint_sha256', 'finished_unix']}
                job['id'] = f"{winner['method']}_{winner['candidate']}_{attack}_seed{seed}"
                cfg = job['config']
                cfg.update(seed=seed, experiment_suite='celeba_seedcheck_v1', experiment_tag=job['id'])
                job.update(output=str(OUT / 'runs' / job['id']), source_hashes=hashes,
                           evidence_stage='fixed_recipe_validation_seed_check',
                           source_selection_job_id=original['id'])
                comparison = dict(cfg)
                comparison.update(seed=91001, experiment_suite=original['config']['experiment_suite'], experiment_tag=original['config']['experiment_tag'])
                assert comparison == original['config'], 'Recipe drift'
                path = OUT / 'jobs' / (job['id'] + '.json')
                write(path, job)
                paths.append(str(path))
    assert len(paths) == len(set(paths)) == 42
    manifest = dict(protocol='celeba_seedcheck_v1', stage='exploratory_validation_seed_check',
                    jobs=paths, output=str(OUT), new_run_count=42, reused_full_count=14,
                    reused_jobs=list(sources.values()), source_hashes=hashes,
                    new_seeds=[91002,91003,91004], reporting_seeds=[91001,91002,91003,91004],
                    evaluation_split='valid', concurrency=8, selected_recipes=selection['methods'],
                    recipe_selection_seed=91001, created_utc=datetime.now(timezone.utc).isoformat())
    write(OUT / 'manifest.json', manifest)
    print(json.dumps(dict(manifest=str(OUT / 'manifest.json'), new_runs=42, reused_runs=14, recipes=selection['methods']), indent=2))
