"""Run frozen training with a cgroup-v1 CPU telemetry path adapter only.
Workers are launched by the unmodified runner using its original __file__.
All job source/config/checkpoint checks remain in the frozen implementation.
"""
import argparse
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("frozen_runner", ROOT / "scripts/run_revision_ablation.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

def platform_path(value):
    if str(value) == "/sys/fs/cgroup/cpu.stat" and not Path(value).exists():
        return Path("/sys/fs/cgroup/cpu/cpu.stat")
    return Path(value)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--concurrency", type=int, default=8)
    parser.add_argument("--first-seeds", type=int, default=0)
    args = parser.parse_args()
    assert platform_path("/sys/fs/cgroup/cpu.stat").is_file()
    runner.Path = platform_path
    runner.run(args)
